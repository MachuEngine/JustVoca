import flet as ft
from ui.app import main
import os

if __name__ == "__main__":
    os.environ["LIBGL_ALWAYS_SOFTWARE"] = "1"
    print("🚀 Flet 앱 시작...")
    print("http://localhost:8101 에서 접속하세요.")

    # xdg-open 오류(헤드리스/서버 환경) 회피:
    # DISPLAY/WAYLAND가 없으면 WEB_BROWSER 대신 WEB_SERVER로 실행
    def _is_headless_linux() -> bool:
        if os.name != "posix":
            return False
        return (not os.environ.get("DISPLAY")) and (not os.environ.get("WAYLAND_DISPLAY"))

    try:
        if _is_headless_linux():
            try:
                view_mode = ft.AppView.WEB_SERVER
            except AttributeError:
                view_mode = "web_server"
        else:
            try:
                view_mode = ft.AppView.WEB_BROWSER
            except AttributeError:
                view_mode = "web_browser"
    except Exception:
        view_mode = "web_server"

    ft.app(target=main, port=8101, view=view_mode, assets_dir="assets")
