import os, json

from constants import SYSTEM_FILE, USERS_FILE, HISTORY_FILE, DEFAULT_SYSTEM
from utils import atomic_write_json, log_write, hash_password, verify_password


def load_system():
    if not os.path.exists(SYSTEM_FILE):
        save_system(DEFAULT_SYSTEM)
        return dict(DEFAULT_SYSTEM)
    try:
        with open(SYSTEM_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        for k, v in DEFAULT_SYSTEM.items():
            if k not in data:
                data[k] = v

        if "api" not in data:
            data["api"] = dict(DEFAULT_SYSTEM["api"])
        for k, v in DEFAULT_SYSTEM["api"].items():
            if k not in data["api"]:
                data["api"][k] = v

        save_system(data)
        return data
    except:
        save_system(DEFAULT_SYSTEM)
        return dict(DEFAULT_SYSTEM)


def save_system(sysdata):
    try:
        atomic_write_json(SYSTEM_FILE, sysdata)
    except Exception as e:
        log_write(f"save_system error: {e}")




def load_users():
    if not os.path.exists(USERS_FILE):
        # 기본 계정도 해시로 저장(안전)
        default_users = {
            "admin": {
                "pw": hash_password("1111"),
                "name": "관리자",
                "role": "admin",
                "country": "KR",
                "progress": {},
            },
            "teacher": {
                "pw": hash_password("1111"),
                "name": "선생님",
                "role": "teacher",
                "country": "KR",
                "progress": {},
            },
            "student": {
                "pw": hash_password("1111"),
                "name": "학습자",
                "role": "student",
                "country": "KR",
                "progress": {},
            },
        }
        save_users(default_users)
        return default_users
    try:
        with open(USERS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 보정
        for uid, u in data.items():
            if "progress" not in u:
                u["progress"] = {}
            if "country" not in u:
                u["country"] = "KR"
            if "pw" not in u:
                u["pw"] = hash_password("1111")
            # [추가] 사양 반영 필드 보정
            if "email" not in u:
                u["email"] = ""
            if "phone" not in u:
                u["phone"] = ""
            if "phone_verified" not in u:
                u["phone_verified"] = False

        save_users(data)
        return data
    except:
        return {}


def save_users(users_data):
    try:
        atomic_write_json(USERS_FILE, users_data)
    except Exception as e:
        log_write(f"save_users error: {e}")

def authenticate_user(user_id: str, password: str):
    """
    return (ok: bool, user: dict|None)
    """
    users = load_users()
    u = users.get(user_id)
    if not u:
        return False, None

    # 저장 구조가 {"pw_hash": "..."} 라고 가정
    pw_hash = u.get("pw_hash", "")
    if not verify_password(password, pw_hash):
        return False, None

    # user dict 안에 id가 없을 수도 있어 보정
    if "id" not in u:
        u["id"] = user_id
    return True, u


def update_user(user_id: str, user: dict):
    users = load_users()
    users[user_id] = user
    save_users(users)


def load_history():
    """
    history.json 로드 (없으면 빈 리스트 반환)
    """
    if not os.path.exists(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        log_write(f"load_history error: {e}")
        return []


def save_history(history_data):
    """
    history.json 저장
    """
    try:
        atomic_write_json(HISTORY_FILE, history_data)
    except Exception as e:
        log_write(f"save_history error: {e}")


def register_user(uid, pw, name, email="", phone="", country="KR", role="student", phone_verified=False):
    users = load_users()
    uid = (uid or "").strip()

    if not uid:
        return False, "아이디를 입력해주세요."
    if uid in users:
        return False, "이미 존재하는 아이디입니다."

    users[uid] = {
        "pw": hash_password(pw),
        "name": name,
        "email": email or "",
        "phone": phone or "",
        "phone_verified": bool(phone_verified),
        "role": role,
        "country": country,
        "progress": {},
    }
    save_users(users)
    return True, "회원가입 완료! 로그인해주세요."


def authenticate_user(uid, pw):
    users = load_users()
    if uid in users:
        stored = users[uid].get("pw", "")
        ok, needs_upgrade = verify_password(stored, pw)
        if ok:
            # legacy plain-text -> hash upgrade
            if needs_upgrade:
                users[uid]["pw"] = hash_password(pw)
                save_users(users)

            u = users[uid]
            u["id"] = uid
            if "progress" not in u:
                u["progress"] = {}
            if "country" not in u:
                u["country"] = "KR"
            save_users(users)
            return True, u
    return False, None


def get_user(uid):
    users = load_users()
    return users.get(uid)


def update_user(uid, new_user_obj):
    users = load_users()
    users[uid] = new_user_obj
    save_users(users)


def ensure_progress(user):
    if "progress" not in user:
        user["progress"] = {}
    if "settings" not in user["progress"]:
        user["progress"]["settings"] = {}
    if "goal" not in user["progress"]["settings"]:
        sysdata = load_system()
        user["progress"]["settings"]["goal"] = int(sysdata.get("default_goal", 10))
    if "ui_lang" not in user["progress"]["settings"]:
        user["progress"]["settings"]["ui_lang"] = "ko"

    if "topics" not in user["progress"]:
        user["progress"]["topics"] = {}

    # 마지막 학습 자리 기억(토픽/인덱스)
    if "last_session" not in user["progress"]:
        user["progress"]["last_session"] = {"topic": "", "idx": 0}
    else:
        if "topic" not in user["progress"]["last_session"]:
            user["progress"]["last_session"]["topic"] = ""
        if "idx" not in user["progress"]["last_session"]:
            user["progress"]["last_session"]["idx"] = 0

    # 격려 화면(하루 1회) 플래그
    if "today_flags" not in user["progress"]:
        user["progress"]["today_flags"] = {}
    if "motivate_shown_date" not in user["progress"]["today_flags"]:
        user["progress"]["today_flags"]["motivate_shown_date"] = ""  # "YYYY-MM-DD"

    return user


