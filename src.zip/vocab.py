import os
from pathlib import Path
import pandas as pd

from utils import log_write

def load_vocab_data():
    """엑셀 파일 로드: sheet_name == 토픽/레벨로 취급"""
    project_root = Path(__file__).resolve().parents[2]  # .../justvoca_refactor
    current_dir = str(project_root)
    data_dir = os.path.join(current_dir, "data", "vocab")
    os.makedirs(data_dir, exist_ok=True)

    excel_path = os.path.join(data_dir, "vocabulary.xlsx")

    if not os.path.exists(excel_path):
        dummy_data = []
        for i in range(1, 21):
            dummy_data.append(
                {
                    "word": f"테스트단어{i}",
                    "mean": "테스트 의미",
                    "ex": f"이것은 예문입니다 {i}",
                    "desc": "설명",
                    "pronunciation": f"[단어{i}]",
                    "image": "📝",
                }
            )
        return {"초급1": dummy_data, "초급2": dummy_data, "중급1": dummy_data}

    try:
        print(f"📂 엑셀 로딩 중... ({excel_path})")
        all_sheets = pd.read_excel(excel_path, sheet_name=None, engine="openpyxl")

        vocab_db = {}
        for sheet_name, df in all_sheets.items():
            df = df.fillna("")
            items = []

            for _, row in df.iterrows():
                cols = row.index.tolist()
                if "단어" not in cols and "word" not in cols:
                    continue

                word_item = {
                    "word": str(row.get("단어", row.get("word", ""))).strip(),
                    "mean": str(row.get("의미", row.get("뜻", row.get("mean", "")))).strip(),
                    "ex": str(row.get("예문", row.get("예문1", row.get("example", "")))).strip(),
                    "desc": str(row.get("설명", row.get("주제", row.get("desc", "")))).strip(),
                    "pronunciation": str(row.get("발음", row.get("pronunciation", ""))).strip(),
                    "image": str(row.get("이미지", row.get("image", "📖"))).strip(),
                }
                if not word_item["pronunciation"] and word_item["word"]:
                    word_item["pronunciation"] = f"[{word_item['word']}]"
                if word_item["word"]:
                    items.append(word_item)

            if items:
                vocab_db[sheet_name] = items
                print(f"✅ [{sheet_name}] 로드 완료 ({len(items)}개)")
        return vocab_db
    except Exception as e:
        print(f"❌ 엑셀 읽기 실패: {e}")
        log_write(f"excel read error: {e}")
        return {}


